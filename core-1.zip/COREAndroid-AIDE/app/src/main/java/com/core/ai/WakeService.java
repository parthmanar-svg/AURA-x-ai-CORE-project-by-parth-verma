package com.core.ai;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.service.voice.VoiceInteractionSession;
import android.speech.RecognitionListener;
import android.speech.RecognitionService;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Background wake-word listener (foreground service with a notification and the mic indicator).
 * V1 uses the phone's speech recognizer in a loop and looks for the wake phrase in the transcript.
 * That works but uses battery and can ding between listens; a dedicated wake-word engine is the upgrade.
 */
public class WakeService extends Service {
    static final String ACTION_STOP = "com.core.ai.WAKE_STOP";
    static final String DEFAULT_PHRASES = "hey core,hey cor,hey corps,hey court,ok core";
    private static final String CHANNEL = "core_wake";
    static volatile boolean running = false;

    private Handler h;
    private SpeechRecognizer rec;
    private PowerManager.WakeLock wl;
    private boolean offline = true;
    private String[] phrases = new String[0];

    private final Runnable startRec = new Runnable() { public void run() { begin(); } };

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        h = new Handler(Looper.getMainLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        startForegroundCompat();
        SharedPreferences sp = getSharedPreferences("core_phone", Context.MODE_PRIVATE);
        phrases = sp.getString("wake_phrases", DEFAULT_PHRASES).toLowerCase(Locale.US).split(",");
        for (int i = 0; i < phrases.length; i++) phrases[i] = phrases[i].trim();
        if (!running) {
            running = true;
            try {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "core:wake");
                wl.acquire();
            } catch (Exception e) { }
            h.post(startRec);
        }
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // swiped away from recents: come back so background listening keeps going
        if (running) {
            try {
                Intent i = new Intent(getApplicationContext(), WakeService.class);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            } catch (Exception e) { }
        }
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        running = false;
        h.removeCallbacksAndMessages(null);
        destroyRec();
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception e) { }
        super.onDestroy();
    }

    private void startForegroundCompat() {
        Notification.Builder nb;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "CORE listening", NotificationManager.IMPORTANCE_LOW));
            nb = new Notification.Builder(this, CHANNEL);
        } else {
            nb = new Notification.Builder(this);
        }
        Intent stop = new Intent(this, WakeService.class).setAction(ACTION_STOP);
        PendingIntent psi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent open = PendingIntent.getActivity(this, 2, new Intent(this, MainActivity.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        nb.setContentTitle("CORE is listening")
                .setContentText("Say \u201chey core\u201d. Tap Stop to turn it off.")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .setContentIntent(open)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", psi);
        Notification n = nb.build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(7, n, 128); // 128 = microphone foreground-service type
        else startForeground(7, n);
    }

    private SpeechRecognizer makeRecognizer() {
        ComponentName pick = null;
        try {
            List<ResolveInfo> l = getPackageManager().queryIntentServices(new Intent(RecognitionService.SERVICE_INTERFACE), 0);
            for (ResolveInfo ri : l) {
                if (ri.serviceInfo == null || getPackageName().equals(ri.serviceInfo.packageName)) continue;
                ComponentName cn = new ComponentName(ri.serviceInfo.packageName, ri.serviceInfo.name);
                if (ri.serviceInfo.packageName.contains("google")) { pick = cn; break; }
                if (pick == null) pick = cn;
            }
        } catch (Exception e) { }
        return pick != null ? SpeechRecognizer.createSpeechRecognizer(this, pick) : SpeechRecognizer.createSpeechRecognizer(this);
    }

    private void begin() {
        if (!running) return;
        destroyRec();
        try {
            rec = makeRecognizer();
            rec.setRecognitionListener(new RecognitionListener() {
                public void onReadyForSpeech(Bundle p) { }
                public void onBeginningOfSpeech() { }
                public void onRmsChanged(float v) { }
                public void onBufferReceived(byte[] b) { }
                public void onEndOfSpeech() { }
                public void onEvent(int t, Bundle p) { }
                public void onPartialResults(Bundle p) { }
                public void onResults(Bundle r) {
                    ArrayList<String> l = r == null ? null : r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String cmd = match(l);
                    if (cmd != null) trigger(cmd);
                    else h.postDelayed(startRec, 150);
                }
                public void onError(int e) {
                    if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stopSelf(); return; }
                    if (e == 12 || e == 13) offline = false; // offline language pack missing: use online recognition
                    long delay = (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) ? 2500
                            : (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) ? 100 : 1000;
                    h.postDelayed(startRec, delay);
                }
            });
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
            i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
            if (offline) i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            rec.startListening(i);
        } catch (Exception e) {
            h.postDelayed(startRec, 3000);
        }
    }

    /** Returns the words spoken after the wake phrase ("" if nothing followed), or null if no wake phrase was heard. */
    private String match(List<String> results) {
        if (results == null) return null;
        for (String r : results) {
            if (r == null) continue;
            String t = r.toLowerCase(Locale.US).trim();
            for (String p : phrases) {
                if (p.length() == 0) continue;
                int idx = t.indexOf(p);
                if (idx >= 0) return t.substring(idx + p.length()).replaceFirst("^[ ,.:;-]+", "").trim();
            }
        }
        return null;
    }

    @SuppressWarnings("deprecation")
    private void wakeScreen() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            PowerManager.WakeLock s = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, "core:screen");
            s.acquire(6000);
        } catch (Exception e) { }
    }

    private void trigger(String cmd) {
        destroyRec();
        wakeScreen();
        boolean shown = false;
        CoreVoiceService svc = CoreVoiceService.instance;
        if (svc != null) {
            try {
                Bundle b = new Bundle();
                b.putString("cmd", cmd);
                svc.showSession(b, VoiceInteractionSession.SHOW_WITH_ASSIST);
                shown = true;
            } catch (Exception e) { }
        }
        if (!shown) {
            try {
                Intent i = new Intent(this, AssistActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("cmd", cmd);
                startActivity(i);
            } catch (Exception e) { }
        }
        h.postDelayed(startRec, 10000); // give the mic to the assistant card first
    }

    private void destroyRec() {
        if (rec != null) { try { rec.destroy(); } catch (Exception e) { } rec = null; }
    }
}
