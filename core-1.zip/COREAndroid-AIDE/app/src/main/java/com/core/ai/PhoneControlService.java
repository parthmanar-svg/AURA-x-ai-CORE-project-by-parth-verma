package com.core.ai;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Path;
import android.os.Build;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import android.graphics.Rect;

import java.util.ArrayList;
import java.util.List;

/** Accessibility service that performs phone actions. Only PhoneBridge calls into it, and only when the user turned phone control on. */
public class PhoneControlService extends AccessibilityService {
    public static volatile PhoneControlService instance;

    // Screens we refuse to tap/type/read on. Edit to taste (matched against the app's package name).
    private static final String[] PROTECTED = {
            "bank", "wallet", "pay", "authenticator", "password", "keepass", "bitwarden", "1password", "lastpass"
    };

    @Override protected void onServiceConnected() { instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) { }
    @Override public void onInterrupt() { }
    @Override public boolean onUnbind(Intent i) { instance = null; return super.onUnbind(i); }
    @Override public void onDestroy() { instance = null; super.onDestroy(); }

    public boolean isProtectedScreen() {
        AccessibilityNodeInfo r = getRootInActiveWindow();
        if (r == null || r.getPackageName() == null) return false;
        String p = r.getPackageName().toString().toLowerCase();
        for (String s : PROTECTED) if (p.contains(s)) return true;
        return false;
    }

    public boolean global(String name) {
        int a;
        if ("home".equals(name)) a = GLOBAL_ACTION_HOME;
        else if ("back".equals(name)) a = GLOBAL_ACTION_BACK;
        else if ("recents".equals(name)) a = GLOBAL_ACTION_RECENTS;
        else if ("notifications".equals(name)) a = GLOBAL_ACTION_NOTIFICATIONS;
        else if ("quick".equals(name)) a = GLOBAL_ACTION_QUICK_SETTINGS;
        else if ("power".equals(name)) a = GLOBAL_ACTION_POWER_DIALOG;
        else if ("screenshot".equals(name)) { if (Build.VERSION.SDK_INT < 28) return false; a = GLOBAL_ACTION_TAKE_SCREENSHOT; }
        else if ("lock".equals(name)) { if (Build.VERSION.SDK_INT < 28) return false; a = GLOBAL_ACTION_LOCK_SCREEN; }
        else return false;
        return performGlobalAction(a);
    }

    /** Tap (same start and end) or swipe. Needs Android 7+. */
    public boolean gesture(float x1, float y1, float x2, float y2, long ms) {
        if (Build.VERSION.SDK_INT < 24) return false;
        try {
            Path p = new Path();
            p.moveTo(x1, y1);
            if (x1 != x2 || y1 != y2) p.lineTo(x2, y2);
            GestureDescription.Builder b = new GestureDescription.Builder();
            b.addStroke(new GestureDescription.StrokeDescription(p, 0, Math.max(1, ms)));
            return dispatchGesture(b.build(), null, null);
        } catch (Throwable t) { return false; }
    }

    public boolean clickText(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || text == null || text.length() == 0) return false;
        List<AccessibilityNodeInfo> hits = root.findAccessibilityNodeInfosByText(text);
        if (hits == null) return false;
        for (AccessibilityNodeInfo n : hits) {
            AccessibilityNodeInfo c = n;
            while (c != null && !c.isClickable()) c = c.getParent();
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
        }
        return false;
    }

    public boolean typeText(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (f == null || f.isPassword()) return false;
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text == null ? "" : text);
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }

    /** forward = "scroll down" (reveal later content). */
    public boolean scroll(boolean forward) {
        AccessibilityNodeInfo n = findScrollable(getRootInActiveWindow(), 0);
        if (n == null) return false;
        return n.performAction(forward ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
    }

    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 25) return null;
        if (n.isScrollable()) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findScrollable(n.getChild(i), depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    /** Visible text on screen (password fields skipped), capped at max chars. */
    public String readScreen(int max) {
        StringBuilder sb = new StringBuilder();
        collect(getRootInActiveWindow(), sb, 0, max);
        return sb.toString().trim();
    }

    private void collect(AccessibilityNodeInfo n, StringBuilder sb, int depth, int max) {
        if (n == null || depth > 30 || sb.length() >= max) return;
        if (!n.isPassword() && n.isVisibleToUser()) {
            CharSequence t = n.getText();
            if (t == null || t.length() == 0) t = n.getContentDescription();
            if (t != null && t.length() > 0) sb.append(t).append('\n');
        }
        for (int i = 0; i < n.getChildCount(); i++) collect(n.getChild(i), sb, depth + 1, max);
    }

    public boolean openApp(String name) {
        if (name == null || name.trim().length() == 0) return false;
        PackageManager pm = getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN);
        q.addCategory(Intent.CATEGORY_LAUNCHER);
        String want = name.toLowerCase().trim(), best = null;
        int bestScore = 0;
        for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
            String label = String.valueOf(ri.loadLabel(pm)).toLowerCase();
            int score = label.equals(want) ? 3 : label.startsWith(want) ? 2 : label.contains(want) ? 1 : 0;
            if (score > bestScore) { bestScore = score; best = ri.activityInfo.packageName; }
        }
        if (best == null) return false;
        Intent li = pm.getLaunchIntentForPackage(best);
        if (li == null) return false;
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(li);
        return true;
    }

    // ---- screen map for the multi-step agent -------------------------------------------------

    private final List<AccessibilityNodeInfo> mapNodes = new ArrayList<AccessibilityNodeInfo>();
    private final List<Boolean> mapPw = new ArrayList<Boolean>();

    public String topPackage() {
        AccessibilityNodeInfo r = getRootInActiveWindow();
        return r == null || r.getPackageName() == null ? "" : r.getPackageName().toString();
    }

    /** Numbered list of what is on screen: [id] kind "label". Password fields are listed as locked, never read. */
    public synchronized String dumpUi(int maxNodes) {
        mapNodes.clear();
        mapPw.clear();
        StringBuilder sb = new StringBuilder();
        sb.append("app: ").append(topPackage()).append('\n');
        walk(getRootInActiveWindow(), sb, 0, maxNodes);
        return sb.toString();
    }

    private void walk(AccessibilityNodeInfo n, StringBuilder sb, int depth, int max) {
        if (n == null || depth > 30 || mapNodes.size() >= max) return;
        if (n.isVisibleToUser()) {
            boolean pw = n.isPassword();
            CharSequence t = n.getText();
            if (t == null || t.length() == 0) t = n.getContentDescription();
            boolean useful = n.isClickable() || n.isEditable() || (t != null && t.length() > 0);
            Rect b = new Rect();
            n.getBoundsInScreen(b);
            if (useful && b.width() > 0 && b.height() > 0) {
                String label = pw ? "[password field - locked]" : (t == null ? "" : t.toString().replace('\n', ' '));
                if (label.length() > 60) label = label.substring(0, 60);
                String kind = pw ? "password" : n.isEditable() ? "textbox" : n.isClickable() ? "button" : "text";
                sb.append('[').append(mapNodes.size()).append("] ").append(kind).append(" \"").append(label).append("\"");
                if (n.isChecked()) sb.append(" (on)");
                if (n.isSelected()) sb.append(" (selected)");
                sb.append('\n');
                mapNodes.add(n);
                mapPw.add(Boolean.valueOf(pw));
            }
        }
        for (int i = 0; i < n.getChildCount(); i++) walk(n.getChild(i), sb, depth + 1, max);
    }

    public synchronized String labelOf(int id) {
        if (id < 0 || id >= mapNodes.size()) return "";
        AccessibilityNodeInfo n = mapNodes.get(id);
        CharSequence t = n.getText();
        if (t == null || t.length() == 0) t = n.getContentDescription();
        return t == null ? "" : t.toString();
    }

    /** Press or focus item [id] from the last dump. Refuses password fields. */
    public synchronized boolean tapId(int id) {
        if (id < 0 || id >= mapNodes.size() || mapPw.get(id).booleanValue()) return false;
        AccessibilityNodeInfo n = mapNodes.get(id);
        AccessibilityNodeInfo c = n;
        while (c != null && !c.isClickable() && !c.isEditable()) c = c.getParent();
        if (c != null && c.performAction(c.isEditable() ? AccessibilityNodeInfo.ACTION_FOCUS : AccessibilityNodeInfo.ACTION_CLICK)) {
            if (c.isEditable()) c.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            return true;
        }
        Rect b = new Rect();
        n.getBoundsInScreen(b);
        return gesture(b.centerX(), b.centerY(), b.centerX(), b.centerY(), 60);
    }
}
