package com.core.ai;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.service.voice.VoiceInteractionSession;

/** Fires when the user holds Home: opens the listening card, then ends the session. */
public class CoreVoiceSession extends VoiceInteractionSession {
    public CoreVoiceSession(Context context) { super(context); }

    @Override
    public void onShow(Bundle args, int showFlags) {
        super.onShow(args, showFlags);
        try {
            Intent i = new Intent(getContext(), AssistActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            String cmd = args == null ? null : args.getString("cmd");
            i.putExtra("cmd", cmd == null ? "" : cmd);
            getContext().startActivity(i);
        } catch (Exception e) { }
        finish();
    }
}
