package com.core.ai;

import android.content.Intent;
import android.speech.RecognitionService;
import android.speech.SpeechRecognizer;

/** Required by Android for assistant apps. CORE listens through the phone's own recognizer instead (see AssistActivity), so this only reports an error. */
public class CoreRecognitionService extends RecognitionService {
    @Override protected void onStartListening(Intent intent, Callback callback) {
        try { callback.error(SpeechRecognizer.ERROR_CLIENT); } catch (Exception e) { }
    }
    @Override protected void onCancel(Callback callback) { }
    @Override protected void onStopListening(Callback callback) { }
}
