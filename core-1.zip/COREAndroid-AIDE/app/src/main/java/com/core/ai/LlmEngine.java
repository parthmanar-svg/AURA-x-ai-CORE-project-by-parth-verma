package com.core.ai;

/** Thin JNI wrapper around libcore_llm.so (llama.cpp). Safe to touch even if the .so is missing. */
public class LlmEngine {
    public interface TokenListener { boolean onToken(String piece); }

    public static boolean available = false;
    public static String loadError = "";

    static {
        try {
            System.loadLibrary("core_llm");
            available = true;
        } catch (Throwable t) {
            available = false;
            loadError = String.valueOf(t.getMessage());
        }
    }

    public static native long nativeLoad(String path, int nCtx, int nThreads);
    public static native void nativeCancel(long handle);
    public static native void nativeFree(long handle);
    public static native String nativeChat(long handle, String[] roles, String[] contents,
                                           int maxTokens, float temp, TokenListener cb);
}
