/* CORE account: Puter sign in / sign out (Settings > Brain). Puter keeps you signed in between launches. */
(function () {
  var doc = document, W = window;
  function $(i) { return doc.getElementById(i); }
  function build() {
    var host = doc.querySelector('[data-tab-content="brain"]');
    if (!host || $('xAcct')) return !!$('xAcct');
    var d = doc.createElement('div'); d.id = 'xAcct'; d.className = 'field';
    d.innerHTML = '<label>Account (Puter, powers the AI)</label><p id="xAcctSt" style="margin-bottom:8px">Checking...</p>' +
      '<button class="panelActionBtn" id="xAcctIn" type="button">Sign in</button> <button class="panelActionBtn" id="xAcctOut" type="button">Sign out</button>' +
      '<p class="note" style="margin-top:10px">Sign in once and CORE logs in automatically on every launch. Google blocks sign-in inside app windows, so use the Puter email/username login. Without an account CORE still answers through the free fallback AIs.</p>';
    host.insertBefore(d, host.firstChild);
    $('xAcctIn').onclick = function () {
      if (!W.puter || !W.puter.auth) { $('xAcctSt').textContent = 'Puter did not load. Check your internet and reopen CORE.'; return; }
      W.puter.auth.signIn().then(refresh).catch(function (e) { $('xAcctSt').textContent = 'Sign in failed: ' + ((e && (e.msg || e.message)) || e); });
    };
    $('xAcctOut').onclick = function () { try { W.puter.auth.signOut(); } catch (e) {} setTimeout(refresh, 300); };
    return true;
  }
  function refresh() {
    var st = $('xAcctSt'); if (!st) return;
    try {
      if (W.puter && W.puter.auth && W.puter.auth.isSignedIn()) {
        st.textContent = 'Signed in';
        W.puter.auth.getUser().then(function (u) { st.textContent = 'Signed in as ' + (u && u.username || 'Puter user'); }).catch(function () {});
        $('xAcctIn').style.display = 'none'; $('xAcctOut').style.display = '';
      } else { st.textContent = W.puter ? 'Not signed in' : 'Puter loading...'; $('xAcctIn').style.display = ''; $('xAcctOut').style.display = 'none'; }
    } catch (e) { st.textContent = 'Not signed in'; }
  }
  var n = 0, t = setInterval(function () { if (build()) refresh(); if (++n > 120) clearInterval(t); }, 1000);
  var o = W.CORE_OPEN_PANEL_TAB; if (o) W.CORE_OPEN_PANEL_TAB = function (x) { var r = o(x); build(); refresh(); return r; };
})();
