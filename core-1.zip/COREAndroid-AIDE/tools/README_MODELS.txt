CORE - running any model on the phone

WHAT RUNS TODAY
- GGUF (Chat, Coding): all llama.cpp architectures. Real format is detected from the file header, so a GGUF named .bin still works.
- To support newer architectures (new Qwen / Gemma / Llama releases), rebuild libcore_llm.so against the latest llama.cpp in your GitHub Actions build and replace the .so in app/src/main/jniLibs/arm64-v8a/. The Java/JS side does not change.

SAFETENSORS / .PT / .PTH
No phone runtime runs these directly. Use tools/convert-model.yml (copy to .github/workflows/ in your repo), run it with the Hugging Face repo name, download the GGUF artifact, add it in Settings > Models.
Fits the free GitHub runner for models up to roughly 7B.

UNCENSORED
The app adds no filtering. Settings > Models > Unrestricted mode (on by default) uses a neutral system prompt, long answers and more memory.
Refusals trained into a model's weights are not removable from the app. For that, load an uncensored or "abliterated" GGUF (search those words on Hugging Face), or convert one with the workflow above.

NOT BUILT YET (stored only): ONNX/ORT, TFLITE chat models, .task, .litertlm. Each needs its own runtime bundled into the app.

ALL OTHER FORMATS (tools/convert-model.yml, target = gguf | onnx | tflite)
- safetensors, .pt/.pth, GPTQ, AWQ -> gguf
- PyTorch, TF SavedModel, Keras/H5, sklearn .pkl -> onnx ; SavedModel/Keras/H5 -> tflite
- .pkl is never opened on the phone (pickle can execute code); it is only converted inside the throwaway GitHub runner.
- Core ML (.mlmodel), TensorRT (.engine), OpenVINO (.xml/.bin) only run on Apple / NVIDIA / Intel hardware. Convert the original model instead.
- ONNX / TFLite / .task / .litertlm runtimes are not bundled yet, so those files are stored but do not run.

GITHUB: .github/workflows/ already holds convert-model.yml and fetch-runtimes.yml. Push this project to a repo and run them from the Actions tab.

TEXT TO IMAGE (Settings > Models > Create image)
- Engine: stable-diffusion.cpp, built as libsd.so by tools/build-sd.yml, placed next to libcore_llm.so in jniLibs/arm64-v8a/.
- Lightest model: SDXS-512 (.safetensors), 1 step, cfg 1. Also SD-Turbo, Segmind tiny-sd, SD 1.5 fine-tunes. Add under "Text to image".
- No filter is added by the app. What a model draws depends on how it was trained.
