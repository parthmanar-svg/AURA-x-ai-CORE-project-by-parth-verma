package com.core.ai;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/** Exposed to the web app as window.CORE_NATIVE. All heavy work runs on worker threads. */
public class CoreBridge {
    public static final int REQ_PICK = 903;

    /** model categories = sub-folders of the models directory */
    private static final String[] CATS = {"chat", "code", "image", "stt", "tts", "vision", "embed", "other"};
    /** model file formats */
    private static final String[] MODEL_EXTS = {"gguf", "onnx", "ort", "tflite", "task", "litertlm", "bin", "safetensors", "pt", "pth",
            "ckpt", "pb", "tf", "keras", "h5", "pkl", "mlmodel", "engine", "xml", "gptq", "awq"};
    /** support files that travel with a model (tokenizers, configs, voices) */
    private static final String[] SUPPORT_EXTS = {"json", "txt", "model", "vocab", "merges"};

    private final Activity activity;
    private final WebView web;
    private long handle = 0;
    private String loadedPath = "";
    private final Object lock = new Object();

    private volatile boolean cancelCopy = false;
    private volatile boolean copying = false;
    private String pendingCat = "chat";

    public CoreBridge(Activity a, WebView w) { activity = a; web = w; }

    // ------------------------------------------------------------------ folders

    private File appRoot() {
        File ext = activity.getExternalFilesDir(null);
        File base = ext != null ? ext : activity.getFilesDir();
        File r = new File(base, "models");
        if (!r.exists()) r.mkdirs();
        return r;
    }

    private File sharedRoot() { return new File(Environment.getExternalStorageDirectory(), "CORE/models"); }

    private static boolean in(String[] arr, String v) {
        for (String s : arr) if (s.equals(v)) return true;
        return false;
    }

    private static String extOf(String name) {
        int dot = name.lastIndexOf('.');
        return dot < 0 ? "" : name.substring(dot + 1).toLowerCase();
    }

    private static String safeName(String n) {
        String s = n == null ? "model" : n.replaceAll("[\\\\/:*?\"<>|\\u0000-\\u001f]", "_").trim();
        if (s.length() == 0) s = "model";
        if (s.length() > 120) {
            String e = extOf(s);
            s = s.substring(0, 100) + (e.length() > 0 ? "." + e : "");
        }
        return s;
    }

    // ------------------------------------------------------------------ status / listing

    @JavascriptInterface
    public String status() {
        try {
            JSONObject o = new JSONObject();
            o.put("available", LlmEngine.available);
            o.put("error", LlmEngine.loadError);
            o.put("loaded", loadedPath);
            JSONObject eng = new JSONObject();
            eng.put("gguf", LlmEngine.available);
            o.put("engines", eng);
            o.put("copying", copying);
            o.put("freeMB", appRoot().getUsableSpace() / (1024 * 1024));
            o.put("imageEngine", new File(activity.getApplicationInfo().nativeLibraryDir, "libsd.so").exists());
            try {
                android.app.ActivityManager am = (android.app.ActivityManager) activity.getSystemService(android.content.Context.ACTIVITY_SERVICE);
                android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                o.put("ramMB", mi.totalMem / (1024 * 1024));
            } catch (Throwable ignored) {}
            o.put("appDir", appRoot().getAbsolutePath());
            o.put("sharedDir", sharedRoot().getAbsolutePath());
            JSONArray dirs = new JSONArray();
            dirs.put(sharedRoot().getAbsolutePath());
            dirs.put(appRoot().getAbsolutePath());
            o.put("dirs", dirs);
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    private void scanRoot(File root, boolean app, JSONArray out) throws Exception {
        if (root == null || !root.isDirectory()) return;
        File[] kids = root.listFiles();
        if (kids == null) return;
        for (File k : kids) {
            if (k.isDirectory() && in(CATS, k.getName())) {
                File[] fs = k.listFiles();
                if (fs == null) continue;
                for (File f : fs) addIfModel(f, k.getName(), app, out);
            } else if (k.isFile()) {
                addIfModel(k, "unsorted", app, out);
            }
        }
    }

    private void addIfModel(File f, String cat, boolean app, JSONArray out) throws Exception {
        if (!f.isFile()) return;
        String n = f.getName(), e = extOf(n);
        boolean model = in(MODEL_EXTS, e), support = in(SUPPORT_EXTS, e);
        if (!model && !(support && !cat.equals("unsorted"))) return;
        String real = model ? sniff(f, e) : e;
        JSONObject m = new JSONObject();
        m.put("name", n);
        m.put("path", f.getAbsolutePath());
        m.put("bytes", f.length());
        m.put("mb", f.length() / (1024 * 1024));
        m.put("cat", cat);
        m.put("fmt", real);
        m.put("ext", e);
        m.put("support", !model);
        m.put("app", app);
        out.put(m);
    }

    /**
     * Identify the real format from the first bytes, so a GGUF renamed to .bin (or a .bin that is
     * really legacy GGML / Whisper) is labelled correctly. Falls back to the file extension.
     */
    private static String sniff(File f, String ext) {
        byte[] b = new byte[16];
        int n = 0;
        InputStream in = null;
        try { in = new FileInputStream(f); n = in.read(b); }
        catch (Throwable t) { return ext; }
        finally { try { if (in != null) in.close(); } catch (Throwable ignored) {} }
        if (n < 4) return ext;
        if (b[0] == (byte) 0x89 && b[1] == 'H' && b[2] == 'D' && b[3] == 'F') return "h5";
        if (b[0] == 'G' && b[1] == 'G' && b[2] == 'U' && b[3] == 'F') return "gguf";
        if (n >= 8 && b[0] == 'L' && b[1] == 'I' && b[2] == 'T' && b[3] == 'E' && b[4] == 'R' && b[5] == 'T') return "litertlm";
        if (n >= 8 && b[4] == 'T' && b[5] == 'F' && b[6] == 'L' && b[7] == '3') return "tflite";
        if (b[2] == 'g' && b[3] == 'g' && ((b[1] == 'm' && (b[0] == 'l' || b[0] == 'f')) || (b[1] == 'j' && b[0] == 't'))) return "ggml";
        if (n >= 9 && b[8] == '{') {
            long len = 0;
            for (int i = 7; i >= 0; i--) len = (len << 8) | (b[i] & 0xFF);
            if (len > 2 && len < 200L * 1024 * 1024) return "safetensors";
        }
        return ext;
    }

    @JavascriptInterface
    public String listModels() {
        JSONArray arr = new JSONArray();
        try {
            scanRoot(appRoot(), true, arr);
            scanRoot(sharedRoot(), false, arr);
        } catch (Exception ignored) {}
        return arr.toString();
    }

    @JavascriptInterface
    public void ensureStoragePermission() {
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            activity.runOnUiThread(new Runnable() {
                public void run() {
                    String p = android.Manifest.permission.READ_EXTERNAL_STORAGE;
                    if (activity.checkSelfPermission(p) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                        activity.requestPermissions(new String[]{p}, 902);
                }
            });
        }
    }

    // ------------------------------------------------------------------ add / delete models

    /** Opens the system file picker; chosen files are copied into models/<cat>/ with progress events. */
    @JavascriptInterface
    public void pickModel(String cat) {
        pendingCat = in(CATS, cat) ? cat : "other";
        activity.runOnUiThread(new Runnable() {
            public void run() {
                try {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    activity.startActivityForResult(i, REQ_PICK);
                } catch (Throwable t) { emit(ev("copyError", null, "Could not open the file picker: " + t)); }
            }
        });
    }

    /** called from MainActivity.onActivityResult */
    public void onPicked(int requestCode, int resultCode, Intent data) {
        if (requestCode != REQ_PICK || resultCode != Activity.RESULT_OK || data == null) return;
        final List<Uri> uris = new ArrayList<Uri>();
        ClipData cd = data.getClipData();
        if (cd != null) { for (int i = 0; i < cd.getItemCount(); i++) uris.add(cd.getItemAt(i).getUri()); }
        else if (data.getData() != null) uris.add(data.getData());
        if (uris.isEmpty()) return;
        final String cat = pendingCat;
        new Thread(new Runnable() { public void run() { copyAll(uris, cat); } }).start();
    }

    private void copyAll(List<Uri> uris, String cat) {
        if (copying) { emit(ev("copyError", null, "Another file is still being added.")); return; }
        copying = true; cancelCopy = false;
        int ok = 0;
        try {
            for (int i = 0; i < uris.size() && !cancelCopy; i++) {
                if (copyOne(uris.get(i), cat, i + 1, uris.size())) ok++;
            }
        } finally {
            copying = false;
            try {
                JSONObject o = new JSONObject();
                o.put("type", "copyDone"); o.put("added", ok); o.put("cancelled", cancelCopy);
                emit(o.toString());
            } catch (Exception ignored) {}
        }
    }

    private boolean copyOne(Uri uri, String cat, int idx, int n) {
        ContentResolver cr = activity.getContentResolver();
        String name = "model"; long size = -1;
        Cursor c = null;
        try {
            c = cr.query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME), si = c.getColumnIndex(OpenableColumns.SIZE);
                if (ni >= 0) name = c.getString(ni);
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
            }
        } catch (Throwable ignored) {
        } finally { if (c != null) c.close(); }

        name = safeName(name);
        String e = extOf(name);
        if (!in(MODEL_EXTS, e) && !in(SUPPORT_EXTS, e)) {
            emit(ev("copyError", null, name + ": unsupported file type (.gguf .onnx .tflite .task .litertlm .bin .safetensors .pt .pth .pb .keras .h5 .pkl .mlmodel .engine .xml, plus .json/.txt/.model tokenizer files)."));
            return false;
        }
        File dir = new File(appRoot(), cat);
        dir.mkdirs();
        if (size > 0 && dir.getUsableSpace() < size + 64L * 1024 * 1024) {
            emit(ev("copyError", null, name + ": not enough free storage (" + (size / (1024 * 1024)) + " MB needed)."));
            return false;
        }
        File dest = new File(dir, name);
        int k = 1;
        while (dest.exists()) {
            int dot = name.lastIndexOf('.');
            String base = dot < 0 ? name : name.substring(0, dot), ext = dot < 0 ? "" : name.substring(dot);
            dest = new File(dir, base + "-" + (k++) + ext);
        }
        File part = new File(dir, dest.getName() + ".part");
        InputStream in = null; OutputStream out = null;
        boolean done = false;
        try {
            in = cr.openInputStream(uri);
            if (in == null) throw new Exception("could not read the file");
            out = new FileOutputStream(part);
            byte[] buf = new byte[1 << 20];
            long total = 0, lastEmit = 0; int r;
            while ((r = in.read(buf)) > 0) {
                if (cancelCopy) break;
                out.write(buf, 0, r);
                total += r;
                long now = System.currentTimeMillis();
                if (now - lastEmit > 300) {
                    lastEmit = now;
                    JSONObject o = new JSONObject();
                    o.put("type", "copy"); o.put("name", dest.getName()); o.put("done", total); o.put("total", size);
                    o.put("idx", idx); o.put("n", n);
                    emit(o.toString());
                }
            }
            out.flush();
            done = !cancelCopy;
        } catch (Throwable t) {
            emit(ev("copyError", null, name + ": " + t.getMessage()));
        } finally {
            try { if (in != null) in.close(); } catch (Throwable ignored) {}
            try { if (out != null) out.close(); } catch (Throwable ignored) {}
        }
        if (done && part.renameTo(dest)) {
            try {
                JSONObject o = new JSONObject();
                o.put("type", "added"); o.put("name", dest.getName()); o.put("cat", cat); o.put("path", dest.getAbsolutePath());
                emit(o.toString());
            } catch (Exception ignored) {}
            return true;
        }
        part.delete();
        return false;
    }

    @JavascriptInterface
    public void cancelCopy() { cancelCopy = true; }

    /** Only files inside the app's own models folder can be deleted. Returns "ok" or a message. */
    @JavascriptInterface
    public String deleteModel(String path) {
        try {
            File f = new File(path).getCanonicalFile();
            File root = appRoot().getCanonicalFile();
            if (!f.getPath().startsWith(root.getPath() + File.separator))
                return "That file isn't managed by the app. Delete it with your file manager.";
            synchronized (lock) {
                if (handle != 0 && f.getPath().equals(loadedPath)) { LlmEngine.nativeFree(handle); handle = 0; loadedPath = ""; }
            }
            return f.delete() ? "ok" : "Could not delete the file.";
        } catch (Exception e) { return "Could not delete: " + e.getMessage(); }
    }

    // ------------------------------------------------------------------ inference (llama.cpp)

    // ------------------------------------------------------------------ text to image (stable-diffusion.cpp)

    private volatile Process imgProc;
    private volatile boolean imgCancelled;

    /** async: emits imgprog (progress text), image (data:image/png;base64,...) or error, all with the same id */
    @JavascriptInterface
    public void generateImage(final String id, final String model, final String prompt, final String neg,
                              final int w, final int h, final int steps, final float cfg, final long seed) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    File exe = new File(activity.getApplicationInfo().nativeLibraryDir, "libsd.so");
                    if (!exe.exists()) { emit(ev("error", id, "Image engine missing. Build libsd.so with tools/build-sd.yml and put it in app/src/main/jniLibs/arm64-v8a/.")); return; }
                    File mf = new File(model);
                    if (!mf.isFile()) { emit(ev("error", id, "Image model file not found.")); return; }
                    File dir = new File(appRoot(), "images");
                    dir.mkdirs();
                    File out = new File(dir, "img_" + System.currentTimeMillis() + ".png");
                    int threads = Math.max(2, Math.min(6, Runtime.getRuntime().availableProcessors() - 1));
                    java.util.ArrayList<String> cmd = new java.util.ArrayList<String>();
                    cmd.add(exe.getAbsolutePath());
                    cmd.add("-m"); cmd.add(mf.getAbsolutePath());
                    cmd.add("-p"); cmd.add(prompt);
                    if (neg != null && neg.trim().length() > 0) { cmd.add("-n"); cmd.add(neg); }
                    cmd.add("-W"); cmd.add(String.valueOf(w));
                    cmd.add("-H"); cmd.add(String.valueOf(h));
                    cmd.add("--steps"); cmd.add(String.valueOf(steps));
                    cmd.add("--cfg-scale"); cmd.add(String.valueOf(cfg));
                    cmd.add("-s"); cmd.add(String.valueOf(seed));
                    cmd.add("-t"); cmd.add(String.valueOf(threads));
                    cmd.add("-o"); cmd.add(out.getAbsolutePath());
                    ProcessBuilder pb = new ProcessBuilder(cmd);
                    pb.redirectErrorStream(true);
                    pb.directory(dir);
                    imgCancelled = false;
                    Process p = pb.start();
                    imgProc = p;
                    InputStream in = p.getInputStream();
                    StringBuilder line = new StringBuilder();
                    String last = "", tail = "";
                    long lastEmit = 0;
                    int c;
                    while ((c = in.read()) != -1) {
                        if (c == '\n' || c == '\r') {
                            String t = line.toString().trim();
                            line.setLength(0);
                            if (t.length() > 0) {
                                last = t.length() > 140 ? t.substring(t.length() - 140) : t;
                                tail = (tail + "\n" + last);
                                if (tail.length() > 600) tail = tail.substring(tail.length() - 600);
                                long now = System.currentTimeMillis();
                                if (now - lastEmit > 400) { lastEmit = now; emit(ev("imgprog", id, last)); }
                            }
                        } else line.append((char) c);
                    }
                    int code = p.waitFor();
                    imgProc = null;
                    if (imgCancelled) { emit(ev("error", id, "Stopped.")); return; }
                    if (code != 0 || !out.exists() || out.length() == 0) { emit(ev("error", id, "Image engine failed (exit " + code + "). " + tail.trim())); return; }
                    java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                    InputStream fin = new FileInputStream(out);
                    try { byte[] buf = new byte[16384]; int n; while ((n = fin.read(buf)) > 0) bos.write(buf, 0, n); }
                    finally { fin.close(); }
                    emit(ev("image", id, "data:image/png;base64," + android.util.Base64.encodeToString(bos.toByteArray(), android.util.Base64.NO_WRAP)));
                } catch (Throwable t) { emit(ev("error", id, String.valueOf(t))); }
            }
        }).start();
    }

    @JavascriptInterface
    public void cancelImage() {
        imgCancelled = true;
        Process p = imgProc;
        if (p != null) p.destroy();
    }

    /** async: emits {type:'loaded'|'error', path} */
    @JavascriptInterface
    public void load(final String path, final int nCtx) {
        new Thread(new Runnable() {
            public void run() {
                synchronized (lock) {
                    try {
                        if (!LlmEngine.available) { emit(ev("error", null, "Native engine missing: " + LlmEngine.loadError)); return; }
                        if (handle != 0 && path.equals(loadedPath)) { emit(ev("loaded", null, path)); return; }
                        if (handle != 0) { LlmEngine.nativeFree(handle); handle = 0; loadedPath = ""; }
                        int threads = Math.max(2, Math.min(6, Runtime.getRuntime().availableProcessors() - 1));
                        long h = LlmEngine.nativeLoad(path, nCtx, threads);
                        if (h == 0) { emit(ev("error", null, "Could not load the model (not enough RAM, or not a valid .gguf).")); return; }
                        handle = h; loadedPath = path;
                        emit(ev("loaded", null, path));
                    } catch (Throwable t) { emit(ev("error", null, String.valueOf(t))); }
                }
            }
        }).start();
    }

    /** messagesJson: [{"role":"user","content":"..."}]; async: emits token / done / error with the same id */
    @JavascriptInterface
    public void chat(final String id, final String messagesJson, final int maxTokens, final float temp) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    final long h;
                    synchronized (lock) { h = handle; }
                    if (h == 0) { emit(ev("error", id, "No model loaded.")); return; }
                    JSONArray a = new JSONArray(messagesJson);
                    String[] roles = new String[a.length()], contents = new String[a.length()];
                    for (int i = 0; i < a.length(); i++) {
                        roles[i] = a.getJSONObject(i).getString("role");
                        contents[i] = a.getJSONObject(i).getString("content");
                    }
                    String out = LlmEngine.nativeChat(h, roles, contents, maxTokens, temp, new LlmEngine.TokenListener() {
                        public boolean onToken(String piece) { emit(ev("token", id, piece)); return true; }
                    });
                    if (out != null && out.startsWith("[error]")) emit(ev("error", id, out.substring(7).trim()));
                    else emit(ev("done", id, out == null ? "" : out));
                } catch (Throwable t) { emit(ev("error", id, String.valueOf(t))); }
            }
        }).start();
    }

    @JavascriptInterface
    public void cancel() { synchronized (lock) { if (handle != 0) LlmEngine.nativeCancel(handle); } }

    @JavascriptInterface
    public void unload() {
        synchronized (lock) { if (handle != 0) { LlmEngine.nativeFree(handle); handle = 0; loadedPath = ""; } }
    }

    public void destroy() { cancelCopy = true; cancelImage(); unload(); }

    // ------------------------------------------------------------------ events to JS

    private String ev(String type, String id, String text) {
        try {
            JSONObject o = new JSONObject();
            o.put("type", type);
            if (id != null) o.put("id", id);
            if (text != null) o.put("text", text);
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    private void emit(final String json) {
        final String js = "window.CORE_NATIVE_EVENT&&window.CORE_NATIVE_EVENT(" + JSONObject.quote(json) + ")";
        activity.runOnUiThread(new Runnable() {
            public void run() { if (web != null) web.evaluateJavascript(js, null); }
        });
    }
}
